<?php

declare(strict_types=1);

namespace Clustering;

use Exception;

class InvalidArgumentException extends Exception
{
}