jQuery.noConflict()(function($){
    "use strict";
    $(document).ready(function() {
        alert('alert');
    });
});
